import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog
import threading

from PIL import Image, ImageTk
from widgets import Label, Button, Slider
from formater import Formater
from object_detector import ObjectDetector


def on_generate_click():
    """Handles object detection when 'Detect Objects' button is clicked."""
    def detect_objects():
        try:
            print('Starting object detection...')
            detector = ObjectDetector.get_instance()
            print('ObjectDetector instance created')
            threshold = slider.get()
            print(f'Selected threshold: {threshold}')

            
            if not hasattr(canvas, 'image_path'):
                print("No image uploaded")
                return

            
            output_path = detector.detect(canvas.image_path, threshold=threshold)
            print(f'Detection completed. Output path: {output_path}')

            
            display_image(output_path)
        except Exception as e:
            print(f"Error during object detection: {e}")

    
    threading.Thread(target=detect_objects).start()


def upload_image():
    """Handles image upload and displays it in the canvas."""
    try:
        image_path = filedialog.askopenfilename(title='Select an Image')
        if not image_path:
            print("No image selected")
            return

        
        copy_path = Formater.get_a_copied_path(image_path)

        
        display_image(copy_path)

        
        canvas.image_path = copy_path
        root.title(f"Image Uploaded: {copy_path.split('/')[-1]}")

    except Exception as e:
        print(f"Error uploading image: {e}")


def display_image(image_path):
    """Displays an image on the canvas."""
    try:
        image = Image.open(image_path)
        tk_image = ImageTk.PhotoImage(image=image)

        
        canvas.config(width=image.width, height=image.height)
        canvas.image = tk_image
        canvas.create_image(0, 0, anchor="nw", image=tk_image)

    except Exception as e:
        print(f"Error displaying image: {e}")



root = ctk.CTk()
root.title("Object Detection App")
ctk.set_appearance_mode("dark")


visible_area = ctk.CTkFrame(root)
visible_area.pack(side="top", expand=True, padx=10, pady=10)


canvas = tk.Canvas(visible_area, width=512, height=512)
canvas.pack(side="left")


buttons_area = ctk.CTkFrame(root)
buttons_area.pack(side="bottom", expand=True, padx=20, pady=20)


title_label = Label(buttons_area, 'Upload an Image and Detect its Objects', 0, 0)
title_label.build()

upload_button = Button(buttons_area, 'Upload', 1, upload_image)
upload_button.build()

threshold_slider = Slider(buttons_area, "Threshold:", 2, 0.1, 1.0, 1000)
slider = threshold_slider.build()

generate_button = Button(buttons_area, 'Detect Objects', 3, on_click=on_generate_click)
generate_button.build()


root.mainloop()
