import tensorflow as tf
from formater import Formater


class ObjectDetector:
    model_path = "TFLite_model/detect.tflite"
    labels_path = "TFLite_model/labelmap.txt"
    
    
    __instance = None

    @classmethod
    def get_instance(cls):
        """Returns a single instance of ObjectDetector (Singleton pattern)."""
        if cls.__instance is None:
            cls.__instance = ObjectDetector()
        return cls.__instance

    def __init__(self):
        """Initializes the TFLite model interpreter and loads labels."""
        if ObjectDetector.__instance is not None:
            raise Exception("This class is a singleton! Use get_instance() method.")
        self.interpreter = tf.lite.Interpreter(model_path=self.model_path)
        self.interpreter.allocate_tensors()

        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()

        
        self.labels = self._load_labels(self.labels_path)

    def _load_labels(self, label_file):
        """Loads labels from the label file."""
        with open(label_file, 'r') as f:
            return {i: label.strip() for i, label in enumerate(f.readlines())}

    def detect(self, image_path, threshold=0.5):
        """
        Runs object detection on the provided image.

        Args:
            image_path (str): Path to the input image.
            threshold (float): Detection threshold for confidence scores.

        Returns:
            output_path (str): Path to the output image with detected objects.
        """
        
        original_image, input_data, height, width = Formater.resize_image(image_path=image_path)

        
        self.interpreter.set_tensor(self.input_details[0]['index'], input_data)
        self.interpreter.invoke()  
        print('Image set to tensor and inference done.')

        
        boxes = self.interpreter.get_tensor(self.output_details[0]['index'])[0]  
        classes = self.interpreter.get_tensor(self.output_details[1]['index'])[0]  
        scores = self.interpreter.get_tensor(self.output_details[2]['index'])[0]  

        print(f'Scores: {scores}')
        print(f'Classes: {classes}')
        print(f'Boxes: {boxes}')

        
        for i in range(len(scores)):
            if scores[i] > threshold:
                original_image = Formater.mark_image(
                    original_image=original_image,
                    coordinates=boxes[i],
                    height=height,
                    width=width,
                    label=self.labels[int(classes[i])],
                    score=scores[i]
                )

        print(f'Final image shape: {original_image.shape}')

        
        output_path = 'temp/output.jpg'
        Formater.save_image(original_image, output_path)

        return output_path
