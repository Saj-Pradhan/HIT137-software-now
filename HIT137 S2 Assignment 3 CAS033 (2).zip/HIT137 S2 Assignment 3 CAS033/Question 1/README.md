"# Object-Detection-Desktop-App" 

## We neet to install library First
```bash
pip install customtkinter
```
## And
```bash
pip install opencv-python
```
## And
```bash
pip install tensorflow
```
