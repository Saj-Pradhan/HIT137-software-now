# ninja-game
A 2D ninja game coded along with this tutorial [ninja-game](https://www.youtube.com/watch?v=2gABYM5M0ww&t=15005s). I added some my own modifications.
<img src="screenshot.png" alt="screenshot" width="600">

